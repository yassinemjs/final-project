import React from 'react';
import UserCard from  './UserCard.js';
function UserList() {
    return (
        <div>
            <UserCard/>
        </div>
    )
}

export default UserList
