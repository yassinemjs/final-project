import React from 'react'

function Posts() {
    return (
        <div>
            
        </div>
    )
}

export default Posts
